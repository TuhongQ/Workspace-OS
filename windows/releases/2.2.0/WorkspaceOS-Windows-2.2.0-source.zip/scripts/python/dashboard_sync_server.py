"""Local-only NEXUS sync API: copy selected one-sided files with progress."""
from __future__ import annotations

import argparse
import json
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from http import HTTPStatus
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlparse

from location_snapshot import build_location_snapshot, save_location_snapshot
from path_safety import is_link_or_reparse
from workspace_paths import paths_for


def _under(root: Path, candidate: Path) -> bool:
    try:
        absolute_root = os.path.abspath(os.path.expanduser(str(root)))
        absolute_candidate = os.path.abspath(os.path.expanduser(str(candidate)))
        return os.path.commonpath([absolute_root, absolute_candidate]) == absolute_root
    except (OSError, ValueError):
        return False


SKIP_PARTS = {
    "#recycle", "@eadir", "$recycle.bin", ".git", ".vs", "__pycache__",
    ".pytest_cache", "node_modules", ".venv",
}


def live_storage(root: Path) -> dict[str, Any]:
    """Query SMB capacity independently of metadata, with a hard timeout."""
    code = "import shutil,json,sys; t,u,f=shutil.disk_usage(sys.argv[1]); print(json.dumps(dict(available=True,total=t,used=u,free=f,percent=round(u/t*100,1) if t else 0)))"
    try:
        result = subprocess.run(
            [sys.executable, "-c", code, str(root)], capture_output=True,
            text=True, timeout=8, check=True,
            creationflags=subprocess.CREATE_NO_WINDOW if os.name == "nt" else 0,
        )
        return json.loads(result.stdout)
    except (subprocess.SubprocessError, OSError, ValueError):
        return {"available": False, "error": "容量查询超时或共享服务器未提供容量；文件访问与容量查询相互独立。"}


def _safe_relative(value: Any, *, allow_empty: bool = False) -> str:
    if not isinstance(value, str):
        raise ValueError("文件路径不安全")
    normalized = value.strip().replace("\\", "/").strip("/")
    if not normalized:
        if allow_empty:
            return ""
        raise ValueError("文件路径不能为空")
    candidate = Path(normalized)
    if candidate.is_absolute() or ".." in candidate.parts:
        raise ValueError("文件路径不安全")
    return candidate.as_posix()


def _covered_by_prefix(relative: str, prefixes: list[str]) -> bool:
    return any(relative == prefix or relative.startswith(prefix.rstrip("/") + "/") for prefix in prefixes)


def _path_available_quick(path: Path, timeout_seconds: int = 5) -> tuple[bool, str]:
    """Avoid hanging worker threads forever on a reconnecting SMB drive."""
    path_text = str(path)
    if os.name == "nt" and path_text.startswith("\\\\"):
        host = path_text.strip("\\").split("\\", 1)[0]
        try:
            with socket.create_connection((host, 445), timeout=timeout_seconds):
                pass
            return True, ""
        except OSError as exc:
            return False, f"NAS 主机 {host}:445 不可连接：{exc}"
    try:
        return path.exists(), "" if path.exists() else f"路径 {path} 当前不可访问"
    except OSError as exc:
        return False, str(exc)


def _target_writable_quick(path: Path, timeout_seconds: int = 5) -> tuple[bool, str]:
    if os.name == "nt" and str(path).startswith("\\\\"):
        return True, ""
    try:
        test_path = path / f".workspace-os-write-test-{uuid.uuid4().hex}.tmp"
        test_path.write_text("ok", encoding="utf-8")
        test_path.unlink(missing_ok=True)
        return True, ""
    except OSError as exc:
        return False, str(exc)


class SyncJobs:
    """In-memory, non-destructive copy jobs bound to exactly two configured roots."""

    def __init__(self, computer: Path, nas: Path, dashboard: Path) -> None:
        self.computer = Path(os.path.abspath(os.path.expanduser(str(computer))))
        self.nas = Path(os.path.abspath(os.path.expanduser(str(nas))))
        self.dashboard = Path(os.path.abspath(os.path.expanduser(str(dashboard))))
        self.jobs_path = self.dashboard.with_name(self.dashboard.stem + ".sync-jobs.json")
        self.jobs: dict[str, dict[str, Any]] = self._load_jobs()
        self.lock = threading.Lock()
        self._last_persist = 0.0

    def _load_jobs(self) -> dict[str, dict[str, Any]]:
        try:
            raw = json.loads(self.jobs_path.read_text(encoding="utf-8"))
            items = raw.get("jobs", []) if isinstance(raw, dict) else []
            jobs = {str(item["id"]): item for item in items if isinstance(item, dict) and item.get("id")}
            for item in jobs.values():
                if item.get("status") in {"queued", "scanning", "running"}:
                    item["status"] = "interrupted"
                    item["current"] = "服务重启，点击重试可从断点继续"
            return jobs
        except (OSError, UnicodeDecodeError, json.JSONDecodeError, TypeError, KeyError):
            return {}

    def _persist_jobs_locked(self, *, force: bool = False) -> None:
        now = time.monotonic()
        if not force and now - self._last_persist < 0.5:
            return
        items = sorted(self.jobs.values(), key=lambda item: item.get("created_at", ""), reverse=True)[:20]
        temporary = self.jobs_path.with_name(self.jobs_path.name + ".partial")
        try:
            temporary.write_text(json.dumps({"jobs": items}, ensure_ascii=False, indent=2), encoding="utf-8")
            os.replace(temporary, self.jobs_path)
            self._last_persist = now
        except OSError:
            try: temporary.unlink(missing_ok=True)
            except OSError: pass

    def _snapshot(self, *, live_nas: bool = False, transferred: list[str] | None = None) -> dict[str, Any]:
        previous_path = self.dashboard.with_suffix(".json")
        previous = None
        try:
            previous = json.loads(previous_path.read_text(encoding="utf-8-sig"))
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            pass
        # Refresh only NAS paths actually copied. Reusing the old NAS cache
        # unchanged made successful uploads continue to appear as missing.
        if transferred and not live_nas:
            previous = previous or {"files": [], "directories": []}
            records = {item["relative"]: item for item in previous.get("files", [])}
            directories = {item["relative"]: item for item in previous.get("directories", [])}
            for relative in transferred:
                path = self.nas / relative
                stat = path.stat()
                record = records.setdefault(relative, {"relative": relative})
                record["nas"] = {
                    "path": str(path), "parent": str(path.parent), "size": stat.st_size,
                    "modified": datetime.fromtimestamp(stat.st_mtime, timezone.utc).isoformat(),
                    "modified_ns": stat.st_mtime_ns,
                }
                # Force comparison again instead of retaining the previous state.
                record.pop("computer", None)
                parent = Path(relative).parent
                while str(parent) != ".":
                    key = parent.as_posix()
                    directories.setdefault(key, {"relative": key})["nas"] = True
                    parent = parent.parent
            previous["files"] = list(records.values())
            previous["directories"] = list(directories.values())
        snapshot = build_location_snapshot(
            self.computer, self.nas, previous=previous, reuse_previous_nas=not live_nas,
            refresh_nas_storage=live_nas,
        )
        save_location_snapshot(snapshot, self.dashboard)
        return snapshot

    def refresh_snapshot(self, *, live_nas: bool = False) -> dict[str, Any]:
        """Re-scan both configured roots and replace the dashboard data."""
        snapshot = self._snapshot(live_nas=live_nas)
        return {
            "ok": True,
            "files": len(snapshot.get("files", [])),
            "refreshed_at": datetime.now(timezone.utc).isoformat(),
        }

    def _append_sync_log(self, job: dict[str, Any], transferred: list[str]) -> str:
        """Append a conflict-safe JSONL record to the canonical NAS .log."""
        now = datetime.now().astimezone()
        log_path = paths_for(self.nas).logs / f"sync-{now:%Y-%m-%d}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)
        direction = "上传到 NAS" if job.get("direction") == "to_nas" else "下载到电脑"
        mode = "覆盖" if job.get("mode") == "overwrite" else "同步"
        errors = len(job.get("errors") or [])
        files = list(dict.fromkeys(str(item).replace("\\", "/") for item in transferred))
        entry = {
            "timestamp": now.isoformat(), "operation": "sync", "direction": direction,
            "mode": mode, "files": files, "file_count": len(files), "errors": errors,
            "job_id": job.get("id"),
        }
        # One append operation preserves entries written by other devices.
        with self.lock:
            with log_path.open("a", encoding="utf-8", newline="") as handle:
                handle.write(json.dumps(entry, ensure_ascii=False, separators=(",", ":")) + "\n")
        return str(log_path)

    def open_folder(self, side: str, relative: str) -> dict[str, Any]:
        if side not in {"computer", "nas"}:
            raise ValueError("无效的位置类型")
        safe = _safe_relative(relative)
        root = self.computer if side == "computer" else self.nas
        target = root / safe
        if target.is_file():
            target = target.parent
        if not target.is_dir():
            raise FileNotFoundError(str(target))
        if os.name == "nt":
            os.startfile(str(target))
        elif shutil.which("open"):
            subprocess.Popen(["open", str(target)])
        else:
            subprocess.Popen(["xdg-open", str(target)])
        return {"ok": True, "path": str(target)}

    def open_folder_path(self, raw_path: str) -> dict[str, Any]:
        value = raw_path.strip()
        if value.lower().startswith("file:///"):
            value = value[8:]
        value = value.replace("/", "\\")
        target = Path(value)
        roots = (self.computer, self.nas)
        if not any(_under(root, target) for root in roots):
            raise ValueError("目录不在已配置的电脑或 NAS 工作区内")
        if target.is_file():
            target = target.parent
        if not target.is_dir():
            raise FileNotFoundError(str(target))
        if os.name == "nt":
            os.startfile(str(target))
        elif shutil.which("open"):
            subprocess.Popen(["open", str(target)])
        else:
            subprocess.Popen(["xdg-open", str(target)])
        return {"ok": True, "path": str(target)}

    def _source_entries_from_prefixes(self, source_root: Path, prefixes: list[str]) -> dict[str, dict[str, Any]]:
        entries: dict[str, dict[str, Any]] = {}
        for prefix in prefixes:
            directory = source_root / prefix
            if not _under(source_root, directory) or not directory.is_dir() or is_link_or_reparse(directory):
                continue
            for current, dirnames, filenames in os.walk(directory):
                current_path = Path(current)
                dirnames[:] = [
                    name for name in dirnames
                    if name.lower() not in SKIP_PARTS
                    and not is_link_or_reparse(current_path / name)
                ]
                for name in filenames:
                    if name.lower() in SKIP_PARTS:
                        continue
                    path = current_path / name
                    try:
                        if is_link_or_reparse(path):
                            continue
                        stat = path.stat()
                        relative = path.relative_to(source_root).as_posix()
                    except (OSError, ValueError):
                        continue
                    if relative.lower().startswith(("09_system/runtimelogs/", "09_system/systemlog/")):
                        continue
                    entries[relative] = {"relative": relative, "size": stat.st_size}
        return entries

    def _source_entries_from_relatives(
        self, source_root: Path, relatives: list[str], mode: str, snapshot: dict[str, Any] | None
    ) -> dict[str, dict[str, Any]]:
        entries: dict[str, dict[str, Any]] = {}
        expected = None
        if mode == "safe":
            expected = "COMPUTER_ONLY" if source_root == self.computer else "NAS_ONLY"
        snapshot_items = {
            item["relative"]: item
            for item in (snapshot or {}).get("files", [])
            if isinstance(item, dict) and item.get("relative")
        }
        for relative in relatives:
            path = source_root / relative
            try:
                if _under(source_root, path) and path.is_file() and not is_link_or_reparse(path):
                    entries[relative] = {"relative": relative, "size": path.stat().st_size}
            except OSError:
                continue
        return entries

    def start(
        self, direction: str, relatives: list[str] | None = None, prefixes: list[str] | None = None,
        mode: str = "safe",
    ) -> dict[str, Any]:
        if direction not in {"to_nas", "to_computer"}:
            raise ValueError("未知同步方向")
        if mode not in {"safe", "overwrite"}:
            raise ValueError("未知同步模式")
        selected = list(dict.fromkeys(_safe_relative(item) for item in (relatives or [])))
        selected_prefixes = list(dict.fromkeys(_safe_relative(item) for item in (prefixes or [])))
        selected_prefixes = [
            prefix for prefix in selected_prefixes
            if not any(prefix != other and prefix.startswith(other.rstrip("/") + "/") for other in selected_prefixes)
        ]
        if not selected and not selected_prefixes:
            raise ValueError("请选择文件或文件夹")
        if len(selected) + len(selected_prefixes) > 5000:
            raise ValueError("一次同步的项目过多，请分批执行")
        job_id = uuid.uuid4().hex
        job = {"id": job_id, "direction": direction, "mode": mode, "status": "queued",
               "total_files": len(selected) + len(selected_prefixes),
               "completed_files": 0, "total_bytes": 0, "copied_bytes": 0,
               "current": "", "errors": [], "created_at": datetime.now(timezone.utc).isoformat()}
        with self.lock:
            self.jobs[job_id] = job
            self._persist_jobs_locked(force=True)
        threading.Thread(target=self._run, args=(job_id, direction, selected, selected_prefixes, mode), daemon=True).start()
        return self.status(job_id)

    def status(self, job_id: str) -> dict[str, Any]:
        with self.lock:
            job = self.jobs.get(job_id)
            if not job:
                raise KeyError(job_id)
            total_files = int(job.get("total_files") or 0)
            total_bytes = int(job.get("total_bytes") or 0)
            if total_files:
                job["completed_files"] = min(int(job.get("completed_files") or 0), total_files)
            if total_bytes:
                job["copied_bytes"] = min(int(job.get("copied_bytes") or 0), total_bytes)
            self._persist_jobs_locked()
            return dict(job)

    def list_jobs(self) -> dict[str, Any]:
        with self.lock:
            for job in self.jobs.values():
                total_files = int(job.get("total_files") or 0)
                total_bytes = int(job.get("total_bytes") or 0)
                if total_files:
                    job["completed_files"] = min(int(job.get("completed_files") or 0), total_files)
                if total_bytes:
                    job["copied_bytes"] = min(int(job.get("copied_bytes") or 0), total_bytes)
            items = [dict(job) for job in self.jobs.values()]
            self._persist_jobs_locked()
        items.sort(key=lambda item: item.get("created_at", ""), reverse=True)
        return {"jobs": items[:20]}

    def _update(self, job_id: str, **values: Any) -> None:
        with self.lock:
            self.jobs[job_id].update(values)
            self._persist_jobs_locked(force=values.get("status") in {"completed", "completed_with_refresh_error"})

    def _add_copied_bytes(self, job_id: str, delta: int) -> None:
        with self.lock:
            job = self.jobs[job_id]
            job["copied_bytes"] = max(0, int(job.get("copied_bytes") or 0) + int(delta))
            self._persist_jobs_locked()

    def _copy_one(self, task: dict[str, Any], mode: str, progress: Any = None) -> None:
        source, target = task["source"], task["target"]
        if not source.is_file() or is_link_or_reparse(source):
            raise RuntimeError("源文件不存在、不是普通文件，或为链接")
        if target.exists() and not target.is_file():
            raise RuntimeError("目标已存在且不是普通文件，已跳过")
        if target.exists() and mode != "overwrite":
            raise RuntimeError("目标已存在；为避免覆盖，已跳过")
        if is_link_or_reparse(target):
            raise RuntimeError("目标为链接，已拒绝写入")
        target.parent.mkdir(parents=True, exist_ok=True)
        if is_link_or_reparse(target.parent):
            raise RuntimeError("目标目录为链接，已拒绝写入")
        before = source.stat()
        # Keep a deterministic partial and sidecar so a retry can resume after a
        # relay/SMB disconnect instead of starting the large file from byte 0.
        temporary = target.with_name(f".{target.name}.workspace-os.partial")
        metadata = temporary.with_suffix(temporary.suffix + ".json")
        source_identity = {
            "source": str(source), "size": int(before.st_size),
            "mtime_ns": int(before.st_mtime_ns),
        }
        try:
            if metadata.is_file():
                saved = json.loads(metadata.read_text(encoding="utf-8"))
            else:
                saved = None
        except (OSError, UnicodeDecodeError, json.JSONDecodeError):
            saved = None
        if saved != source_identity:
            try:
                temporary.unlink(missing_ok=True); metadata.unlink(missing_ok=True)
            except OSError:
                pass
        try:
            metadata.write_text(json.dumps(source_identity, ensure_ascii=False), encoding="utf-8")
        except OSError as exc:
            raise RuntimeError(f"无法创建断点续传记录：{exc}") from exc
        resumed = 0
        try:
            if temporary.is_file():
                resumed = temporary.stat().st_size
                if resumed > before.st_size:
                    temporary.unlink(missing_ok=True); resumed = 0
        except OSError:
            resumed = 0
        reported_bytes = 0
        try:
            if progress and resumed:
                progress(resumed)
            with source.open("rb") as source_file, temporary.open("ab") as target_file:
                source_file.seek(resumed)
                while True:
                    # Smaller requests are materially more reliable over a
                    # slow relay while still making progress visible quickly.
                    chunk = source_file.read(2 * 1024 * 1024)
                    if not chunk:
                        break
                    target_file.write(chunk)
                    reported_bytes += len(chunk)
                    if progress:
                        progress(len(chunk))
            shutil.copystat(source, temporary, follow_symlinks=False)
            # Overwrite changes conflict policy, not transfer integrity checks.
            after = source.stat()
            if before.st_size != after.st_size or before.st_mtime_ns != after.st_mtime_ns:
                raise RuntimeError("复制期间源文件发生变化")
            if temporary.stat().st_size != before.st_size:
                raise RuntimeError("复制后大小不一致")
            if target.exists() and mode != "overwrite":
                raise RuntimeError("复制期间目标已出现同名文件；为避免覆盖，已停止")
            os.replace(temporary, target)
            metadata.unlink(missing_ok=True)
        except Exception:
            if progress and reported_bytes:
                progress(-reported_bytes)
            raise
        finally:
            # On failure intentionally retain the partial and sidecar for the
            # next retry. Successful commit removes both above.
            if target.is_file():
                try:
                    temporary.unlink(missing_ok=True); metadata.unlink(missing_ok=True)
                except OSError:
                    pass

    def _copy_one_with_robocopy(self, source: Path, target: Path, mode: str) -> None:
        before = source.stat()
        command = [
            "robocopy", str(source.parent), str(target.parent), source.name,
            "/COPY:DAT", "/DCOPY:DAT", "/R:1", "/W:1", "/XJ",
            "/NJH", "/NJS", "/NP",
        ]
        if mode == "overwrite":
            command.extend(["/IS", "/IT"])
        else:
            command.extend(["/XC", "/XN", "/XO"])
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=creationflags,
            timeout=1800,
        )
        if result.returncode >= 8:
            message = (result.stderr or result.stdout or "Windows 复制失败").strip()
            raise RuntimeError(message.splitlines()[-1] if message else "Windows 复制失败")
        if not target.is_file():
            raise RuntimeError("Windows 复制未生成目标文件")
        if mode != "overwrite":
            after = source.stat()
            if before.st_size != after.st_size or before.st_mtime_ns != after.st_mtime_ns:
                raise RuntimeError("复制期间源文件发生变化")
            if target.stat().st_size != before.st_size:
                raise RuntimeError("复制后大小不一致")

    def _robocopy_directory(self, source: Path, target: Path, mode: str) -> None:
        if not source.is_dir() or is_link_or_reparse(source):
            raise RuntimeError("源文件夹不存在、不是普通文件夹，或为链接")
        target.mkdir(parents=True, exist_ok=True)
        if is_link_or_reparse(target):
            raise RuntimeError("目标文件夹为链接，已拒绝写入")
        command = [
            "robocopy", str(source), str(target),
            "/E", "/COPY:DAT", "/DCOPY:DAT", "/R:1", "/W:1", "/XJ", "/MT:16",
            "/NJH", "/NJS", "/NP",
        ]
        if mode == "overwrite":
            command.extend(["/IS", "/IT"])
        else:
            command.extend(["/XC", "/XN", "/XO"])
        command.extend(["/XD", *sorted(SKIP_PARTS)])
        creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        result = subprocess.run(
            command,
            text=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            creationflags=creationflags,
            timeout=7200,
        )
        if result.returncode >= 8:
            message = (result.stderr or result.stdout or "Windows 文件夹复制失败").strip()
            raise RuntimeError(message.splitlines()[-1] if message else "Windows 文件夹复制失败")

    def _run(self, job_id: str, direction: str, selected: list[str], prefixes: list[str], mode: str) -> None:
        self._update(job_id, status="scanning", current="正在生成同步任务…")
        try:
            snapshot = None
            try:
                snapshot = json.loads(self.dashboard.with_suffix(".json").read_text(encoding="utf-8-sig"))
            except (OSError, UnicodeDecodeError, json.JSONDecodeError):
                snapshot = None
            source_root, target_root = (self.computer, self.nas) if direction == "to_nas" else (self.nas, self.computer)
            for root, label in ((source_root, "源路径"), (target_root, "目标路径")):
                ok, message = _path_available_quick(root)
                if not ok:
                    raise RuntimeError(f"{label}不可访问：{message}")
            ok, message = _target_writable_quick(target_root)
            if not ok:
                raise RuntimeError(f"目标路径不可写：{message}")
            selected_entries = self._source_entries_from_relatives(source_root, selected, mode, snapshot)
            if prefixes:
                selected_entries = {
                    relative: item for relative, item in selected_entries.items()
                    if not _covered_by_prefix(relative, prefixes)
                }
            prefix_entries = self._source_entries_from_prefixes(source_root, prefixes)
            entries = dict(selected_entries)
            entries.update(prefix_entries)
            tasks = []
            prefix_tasks = []
            missing = [item for item in selected if item not in entries]
            for prefix in prefixes:
                source_directory, target_directory = source_root / prefix, target_root / prefix
                prefix_items = [
                    {"relative": relative, "source": source_root / relative,
                     "target": target_root / relative, "size": item["size"]}
                    for relative, item in prefix_entries.items()
                    if relative == prefix or relative.startswith(prefix.rstrip("/") + "/")
                    if mode == "overwrite" or not (target_root / relative).is_file()
                ]
                if not _under(source_root, source_directory) or not _under(target_root, target_directory):
                    missing.append(prefix); continue
                if not source_directory.exists():
                    missing.append(prefix); continue
                prefix_tasks.append({
                    "relative": prefix, "source": source_directory, "target": target_directory,
                    "files": prefix_items,
                    "empty_unit": 1 if not prefix_items else 0,
                    "total_files": len(prefix_items), "total_bytes": sum(int(item["size"]) for item in prefix_items),
                })
            for relative, item in sorted(selected_entries.items()):
                source, target = source_root / relative, target_root / relative
                if not _under(source_root, source) or not _under(target_root, target):
                    missing.append(relative); continue
                if mode != "overwrite" and target.exists():
                    continue
                tasks.append({"relative": relative, "source": source, "target": target, "size": item["size"]})
            with self.lock:
                job = self.jobs[job_id]
                job["total_files"] = len(tasks) + sum(item["total_files"] + item["empty_unit"] for item in prefix_tasks)
                job["total_bytes"] = sum(item["size"] for item in tasks) + sum(item["total_bytes"] for item in prefix_tasks)
                job["errors"].extend({"relative": item, "message": "文件状态已变化，已跳过"} for item in missing)
            self._update(job_id, status="running", current="")
        except Exception as exc:
            self._update(job_id, status="completed_with_refresh_error", current="", refresh_error=str(exc))
            return
        transferred = []
        for task in prefix_tasks:
            self._update(job_id, current=f"Windows 正在高速复制文件夹：{task['relative']}")
            try:
                # Preserve the complete directory tree, including nested empty folders.
                for current, dirnames, _filenames in os.walk(task["source"]):
                    current_path = Path(current)
                    dirnames[:] = [
                        name for name in dirnames
                        if name.lower() not in SKIP_PARTS
                        and not is_link_or_reparse(current_path / name)
                    ]
                    relative_directory = current_path.relative_to(source_root)
                    destination_directory = target_root / relative_directory
                    if not _under(target_root, destination_directory):
                        raise RuntimeError("目标文件夹路径不安全")
                    destination_directory.mkdir(parents=True, exist_ok=True)
                if task["empty_unit"]:
                    with self.lock:
                        self.jobs[job_id]["completed_files"] += 1
                # File progress is updated only after each target is written and verified.
                for file_task in task["files"]:
                    self._update(job_id, current=file_task["relative"])
                    self._copy_one(
                        file_task, mode,
                        lambda delta, current_job=job_id: self._add_copied_bytes(current_job, delta),
                    )
                    transferred.append(file_task["relative"])
                    with self.lock:
                        self.jobs[job_id]["completed_files"] += 1
            except Exception as exc:
                with self.lock:
                    self.jobs[job_id]["errors"].append({"relative": task["relative"], "message": str(exc)})
        for task in tasks:
            self._update(job_id, current=task["relative"])
            try:
                self._copy_one(
                    task, mode,
                    lambda delta, current_job=job_id: self._add_copied_bytes(current_job, delta),
                )
                transferred.append(task["relative"])
                with self.lock:
                    self.jobs[job_id]["completed_files"] += 1
            except Exception as exc:  # Preserve successfully copied prior files; never roll them back.
                with self.lock:
                    self.jobs[job_id]["errors"].append({"relative": task["relative"], "message": str(exc)})
        try:
            self._update(job_id, current="正在刷新差异列表…")
            # A local test workspace can be re-scanned immediately. For a
            # relayed UNC NAS, avoid blocking the completed job on a full SMB
            # walk; the user can explicitly press “刷新目录” for live NAS data.
            live_after_copy = not (os.name == "nt" and str(self.nas).startswith("\\\\"))
            self._snapshot(live_nas=live_after_copy, transferred=transferred)
            try:
                log_path = self._append_sync_log(self.jobs[job_id], transferred)
                self._update(job_id, status="completed", current="", log_path=log_path,
                             refreshed_at=datetime.now(timezone.utc).isoformat())
            except OSError as log_exc:
                # File transfer remains successful; expose the log failure so it is actionable.
                self._update(job_id, status="completed", current="同步完成，但 NAS .log 写入失败",
                             log_error=str(log_exc), refreshed_at=datetime.now(timezone.utc).isoformat())
        except Exception as exc:
            self._update(
                job_id, status="completed_with_refresh_error", current="",
                refresh_error=str(exc), refreshed_at="",
            )


def serve(computer: str, nas: str, dashboard: str, port: int) -> None:
    jobs = SyncJobs(Path(computer), Path(nas), Path(dashboard))
    activity = {"last": time.monotonic()}
    idle_timeout = 30.0

    class Handler(BaseHTTPRequestHandler):
        def log_message(self, _format: str, *_args: Any) -> None:
            return

        def send_json(self, status: int, body: dict[str, Any]) -> None:
            data = json.dumps(body, ensure_ascii=False).encode("utf-8")
            self.send_response(status); self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(data))); self.end_headers(); self.wfile.write(data)

        def do_GET(self) -> None:
            activity["last"] = time.monotonic()
            path = urlparse(self.path).path
            if path == "/api/health":
                self.send_json(HTTPStatus.OK, {
                    "ok": True,
                    "api_version": "2.1",
                    "computer": str(jobs.computer),
                    "nas": str(jobs.nas),
                    "dashboard": str(jobs.dashboard),
                })
                return
            if path == "/api/sync/jobs":
                self.send_json(HTTPStatus.OK, jobs.list_jobs())
                return
            if path == "/api/storage":
                self.send_json(HTTPStatus.OK, {"nas_storage": live_storage(jobs.nas)})
                return
            if path == "/api/open-folder":
                try:
                    query = parse_qs(urlparse(self.path).query)
                    side = (query.get("side") or [""])[0]
                    relative = (query.get("relative") or [""])[0]
                    self.send_json(HTTPStatus.OK, jobs.open_folder(side, relative))
                except (ValueError, FileNotFoundError, OSError) as exc:
                    self.send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return
            if path == "/api/open-folder-path":
                try:
                    query = parse_qs(urlparse(self.path).query)
                    raw_path = (query.get("path") or [""])[0]
                    self.send_json(HTTPStatus.OK, jobs.open_folder_path(raw_path))
                except (ValueError, FileNotFoundError, OSError) as exc:
                    self.send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
                return
            if path in {"/", "/dashboard"}:
                try:
                    content = jobs.dashboard.read_bytes()
                except OSError as exc:
                    self.send_json(HTTPStatus.NOT_FOUND, {"error": str(exc)}); return
                self.send_response(HTTPStatus.OK); self.send_header("Content-Type", "text/html; charset=utf-8")
                self.send_header("Cache-Control", "no-store")
                self.send_header("Content-Length", str(len(content))); self.end_headers(); self.wfile.write(content); return
            if path.startswith("/api/sync/jobs/"):
                try:
                    self.send_json(HTTPStatus.OK, jobs.status(path.rsplit("/", 1)[-1]))
                except KeyError:
                    self.send_json(HTTPStatus.NOT_FOUND, {"error": "任务不存在"})
                return
            self.send_json(HTTPStatus.NOT_FOUND, {"error": "not found"})

        def do_POST(self) -> None:
            activity["last"] = time.monotonic()
            path = urlparse(self.path).path
            if path == "/api/refresh":
                try:
                    query = urlparse(self.path).query
                    live_nas = "live=1" in query or "live=true" in query.lower()
                    self.send_json(HTTPStatus.OK, jobs.refresh_snapshot(live_nas=live_nas))
                except Exception as exc:
                    self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})
                return
            if path != "/api/sync/jobs":
                self.send_json(HTTPStatus.NOT_FOUND, {"error": "not found"}); return
            try:
                length = int(self.headers.get("Content-Length", "0"))
                if length > 1_000_000:
                    raise ValueError("请求过大")
                body = json.loads(self.rfile.read(length).decode("utf-8"))
                result = jobs.start(
                    body.get("direction"),
                    body.get("relatives") or [],
                    body.get("prefixes") or [],
                    body.get("mode") or "safe",
                )
                self.send_json(HTTPStatus.ACCEPTED, result)
            except (ValueError, TypeError, json.JSONDecodeError) as exc:
                self.send_json(HTTPStatus.BAD_REQUEST, {"error": str(exc)})
            except Exception as exc:
                self.send_json(HTTPStatus.INTERNAL_SERVER_ERROR, {"error": str(exc)})

    server = ThreadingHTTPServer(("127.0.0.1", port), Handler)

    def reap_when_idle() -> None:
        while True:
            time.sleep(5)
            if time.monotonic() - activity["last"] < idle_timeout:
                continue
            running = any(job.get("status") in {"queued", "scanning", "running"} for job in jobs.list_jobs().get("jobs", []))
            if running:
                activity["last"] = time.monotonic()
                continue
            server.shutdown()
            return

    threading.Thread(target=reap_when_idle, name="workspace-os-dashboard-idle-reaper", daemon=True).start()
    server.serve_forever()


def main() -> int:
    parser = argparse.ArgumentParser(description="Workspace OS local dashboard sync service")
    parser.add_argument("--computer", required=True); parser.add_argument("--nas", required=True)
    parser.add_argument("--dashboard", required=True); parser.add_argument("--port", type=int, default=8765)
    args = parser.parse_args()
    serve(args.computer, args.nas, args.dashboard, args.port)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
