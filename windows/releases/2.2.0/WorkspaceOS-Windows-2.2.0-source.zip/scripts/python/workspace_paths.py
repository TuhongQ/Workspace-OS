"""Canonical Workspace OS 2026 directory profile."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

MODERN_LAYOUT = {
    "00_Inbox": ["Mobile", "ToSort"],
    "01_Projects": ["Work", "Work/Active", "Work/Paused", "Work/Completed",
                    "Personal", "Personal/Active", "Personal/Paused", "Personal/Completed"],
    "02_The-Wisdom-Playbook": ["21_LifeAtlas", "22_Knowledge", "23_Assets"],
    "03_Files": ["视频照片", "工具软件"],
    "09_System": ["Backups", "Bridge-Core", "Copilot-Prompts", "LifeOS",
                   "Repository-Maintenance", "RuntimeLogs", "SystemLog"],
    "99_Archive": [],
}


def is_modern_workspace(root: str | Path) -> bool:
    path = Path(root).expanduser()
    return (path / "02_The-Wisdom-Playbook").is_dir() and (path / "09_System").is_dir()


def layout_for(root: str | Path) -> dict[str, list[str]]:
    return MODERN_LAYOUT


@dataclass(frozen=True)
class WorkspacePaths:
    root: Path
    modern: bool = True

    @property
    def system(self) -> Path:
        return self.root / "09_System"

    @property
    def indexes(self) -> Path:
        return self.system / "RuntimeLogs" / "WorkspaceOS" / "Indexes"

    @property
    def logs(self) -> Path:
        return self.system / "SystemLog" / "WorkspaceOS"

    @property
    def backups(self) -> Path:
        return self.system / "Backups" / "WorkspaceOS"

    @property
    def knowledge(self) -> Path:
        return self.root / "02_The-Wisdom-Playbook" / "22_Knowledge"


def paths_for(root: str | Path) -> WorkspacePaths:
    path = Path(root).expanduser().resolve()
    return WorkspacePaths(path, is_modern_workspace(path))
