# Windows 集成版安装说明

## 安装包位置

最新 Windows 集成安装包位于：

`D:\Workspace\03_Files\工具软件\WorkspaceOS\Installers`

安装包名称为 `WorkspaceOS-NEXUS-Integrated-Windows-2.2.0-Setup.exe`，旁边的同名 `.sha256` 文件用于校验下载完整性。

## 安装步骤

1. 双击安装包并按提示完成安装。安装时可选择创建桌面快捷方式；开始菜单入口和卸载入口由安装程序创建。
2. 安装后从开始菜单或桌面启动 Workspace OS NEXUS。控制中心和网页工作台在同一个程序窗口中打开。
3. 在控制中心确认电脑工作区路径，例如 `D:\Workspace`。
4. 填写 NAS 共享路径，例如 `\\192.168.1.9\Workspace` 或新电脑实际使用的 UNC 路径，然后测试连接并保存。
5. 点击保存并打开工作台，使用文件查找、左右对比、上传、下载和覆盖功能。

安装包带有 Python 与 .NET 运行组件，无须另行安装这些开发运行环境。WebView2 Runtime 是网页显示所需组件；若电脑上缺少，安装程序会尝试启动其安装程序。NAS 账号与密码由 Windows 凭据管理和资源管理器连接状态提供，不要把它们写进配置文件或安装包。

## 工作日志位置

系统工作日志统一保存为 `.log`，路径为：

`D:\Workspace\09_System\SystemLog\WorkspaceOS`

命令行 Inbox 操作会生成独立操作日志；网页上传/下载会在 NAS 的相同相对目录追加同步日志。索引和运行报告位于 `D:\Workspace\09_System\RuntimeLogs\WorkspaceOS\Indexes`，与 `.log` 工作日志分开保存。新版不会自动创建 `02_Knowledge\ObsidianVault\01_Daily` 或 Markdown 工作日志。

## 卸载与升级

通过 Windows“设置 → 应用”或开始菜单中的 Workspace OS 卸载入口卸载。升级时关闭 Workspace OS 窗口后运行新版安装包。卸载程序移除应用文件，不会主动删除你配置的电脑 Workspace 或 NAS 中的资料。
